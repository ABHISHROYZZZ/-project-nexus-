# Technologies Used

1. HTML (Hyper Text Markup Language)
2. CSS (Cascading Style Sheets)
3. JS (JavaScript)