![Preview](/assets/img/preview.png)

<h1 align="center">
    Animated login and registration form!
</h1>

<p align="center">
    A responsive registration and login form in HTML, CSS and JavaScript.
</p>

<h4 align="center"> 
	Currently developing my frontend and backend skills by going back to basics...  🚧
</h4>
